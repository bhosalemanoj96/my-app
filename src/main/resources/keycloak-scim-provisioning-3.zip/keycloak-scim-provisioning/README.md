# keycloak-scim-provisioning

A Keycloak **Event Listener SPI** extension that pushes user/group provisioning changes to your
SCIM server, using the Captain-P-Goldfish `scim-sdk-client` library — the same SDK family as your
`scim-sdk-server` implementation. This makes Keycloak a second SCIM-provisioning source alongside
Azure AD.

## Operations covered

| Keycloak action                                   | Trigger                          | SCIM call                          |
|----------------------------------------------------|-----------------------------------|-------------------------------------|
| Create user (admin console / Admin REST / self-register) | AdminEvent / Event               | `POST /Users`                      |
| Update user (profile, enable/disable, name, email)  | AdminEvent / Event (UPDATE_PROFILE) | `PUT /Users/{id}`                |
| Delete user                                         | `UserModel.UserRemovedEvent`      | `DELETE /Users/{id}`               |
| Create group                                        | AdminEvent                       | `POST /Groups`                     |
| Update group (rename)                               | AdminEvent                       | `PUT /Groups/{id}`                 |
| Delete group                                        | `GroupModel.GroupRemovedEvent`   | `DELETE /Groups/{id}`              |
| User joins group                                    | AdminEvent (GROUP_MEMBERSHIP, CREATE) | `PATCH /Groups/{id}` (add member) |
| User leaves group                                   | AdminEvent (GROUP_MEMBERSHIP, DELETE) | `PATCH /Groups/{id}` (remove member) |

Realm role / client role mappings are **not** mapped to SCIM groups in this phase — add that in
`ScimEventListenerProvider` if you need it (map `ResourceType.REALM_ROLE_MAPPING` similarly to
`GROUP_MEMBERSHIP`).

## Why DELETE is handled differently

Keycloak's `AdminEvent` for a DELETE operation fires *after* the entity is gone, with no
representation — there's nothing to read the SCIM external ID from. Instead this extension
registers `KeycloakSessionFactory` model-event listeners (`UserModel.UserRemovedEvent`,
`GroupModel.GroupRemovedEvent`) in `postInit()`. These fire synchronously, inside the same
transaction as the removal, while the entity is still readable, so the `scimExternalId` attribute
can be captured before it disappears. Only the actual outbound HTTP DELETE is dispatched
asynchronously — reading the attribute itself is synchronous and cheap.

## Correlation / external ID tracking

Each Keycloak user/group gets a single attribute (default name `scimExternalId`, configurable)
holding the SCIM server's assigned resource ID once first synced. Its presence is what
distinguishes "needs POST" from "needs PUT/PATCH".

## Build

Versions are pinned to what you're running elsewhere: Keycloak 26.6.3, `scim-sdk-client` 1.32.0
(matching your `scim-sdk-server` version), JDK 21. Update `keycloak.version`/`scim.sdk.version` in
`pom.xml` if either changes later.

```bash
mvn clean package
```

This produces `target/keycloak-scim-provisioning.jar`, shaded with the SCIM-SDK client and its
HTTP client dependencies (Keycloak's own SPI/core jars stay `provided` and are not shaded, to
avoid classpath conflicts with what the server already provides).

## Deploy

Copy the jar into Keycloak's providers directory and rebuild:

```bash
cp target/keycloak-scim-provisioning.jar $KEYCLOAK_HOME/providers/
$KEYCLOAK_HOME/bin/kc.sh build
```

## Configure

Via `keycloak.conf` / CLI (preferred):

```
spi-events-listener-scim-provisioning-scim-base-url=https://your-scim-server.example.com/scim/v2
spi-events-listener-scim-provisioning-auth-mode=BEARER
spi-events-listener-scim-provisioning-bearer-token=${env.SCIM_BEARER_TOKEN}
spi-events-listener-scim-provisioning-async-threads=2
```

Or via env vars as a fallback: `SCIM_BASE_URL`, `SCIM_AUTH_MODE` (`NONE`/`BASIC`/`BEARER`),
`SCIM_BASIC_USERNAME`/`SCIM_BASIC_PASSWORD`, `SCIM_BEARER_TOKEN`, `SCIM_EXTERNAL_ID_ATTRIBUTE`,
`SCIM_ASYNC_THREADS`, `SCIM_CONNECT_TIMEOUT`, `SCIM_REQUEST_TIMEOUT`, `SCIM_SKIP_TLS_VERIFY`.

Then enable the listener on the realm: Admin Console → Realm Settings → Events → Event Listeners
→ add `scim-provisioning`. **Also enable "Save events" for admin events with "include
representation" on**, or AdminEvent payloads may not carry what's needed.

## Admin console UI (optional, experimental)

There's now a **"SCIM Provisioning" tab under Realm Settings** (`ScimConfigTab`) where you can set
the SCIM base URL, auth mode, credentials, and external-ID attribute *per realm*, instead of only
via `keycloak.conf`/env vars. Anything left blank in the UI falls back to the server-level default.
Saving the form invalidates that realm's cached SCIM client so the next event picks up the new
config immediately.

**This requires the experimental `declarative-ui` feature flag:**
```
kc.sh start --features=declarative-ui
```
(or add `features=declarative-ui` to `keycloak.conf`). Without it, the tab won't appear at all, and
the extension just falls back to the server-level `ScimProvisioningConfig` for every realm — no
event-processing behavior depends on the UI feature being enabled.

Do **not** treat this UI piece with the same confidence as the rest of the extension — it's built
on `org.keycloak.services.ui.extend.UiTabProvider`, which is a Keycloak preview/experimental SPI,
not a stable public API. I confirmed its exact shape (`onCreate`, `getConfigProperties()`,
`getPath()`/`getParams()`) against Keycloak's own `extend-admin-console-spi` quickstart source, but
I could not verify how the admin console pre-fills the form with previously-saved values from that
single example — check that round-trips correctly in your Keycloak version before relying on it for
more than a dev/test setup. If it doesn't, `keycloak.conf`/`KC_SPI_*` env vars remain the reliable
fallback path (see above) and the extension works identically either way.

Also worth deciding deliberately: realm attributes aren't encrypted at rest, so the bearer
token/basic-auth password saved through this tab sit in the DB in plain text, visible via the
realm's REST/export representation like any other attribute. If that's not acceptable for your
threat model, swap `ScimConfigTab`/`ScimClientHolder` to store a vault alias instead and resolve the
actual secret through Keycloak's vault SPI.

## Known issue fixed: user/group lookup returning null in the async job

Earlier versions of this extension submitted straight to the background executor from inside
`onEvent(...)`. That races the surrounding admin request's transaction commit: `AdminEvent` fires
*before* commit, so a background job opening its own fresh session (via `runJobInTransaction`)
could run before the new user/group row is actually visible in the database, and
`getUserById`/`getGroupById` would spuriously return `null` even though the entity really was
created. Fixed by deferring the `executor.submit(...)` call itself until after this session's
transaction commits, via `KeycloakTransactionManager.enlistAfterCompletion(...)` — see
`ScimEventListenerProvider.afterCommit(...)`. That hook runs synchronously right after commit
(cheap — it's just enqueuing a task), so it adds negligible latency to the admin REST response;
only the outbound SCIM HTTP call itself happens later, on the background executor.

## Things worth verifying before you trust this in anything beyond a dev/test integration

1. **Bearer auth wiring** (`ScimClientHolder`): the SCIM-SDK client wiki only documents
   `basicAuth(...)` and client-cert auth directly on `ScimClientConfig`; bearer token support here
   is implemented via a preconfigured Apache `HttpClientBuilder` interceptor, based on release
   notes mentioning that `ScimClientConfig` accepts preconfigured http-client-builders. Check your
   exact `scim-sdk-client` version's `ScimClientConfig` for a dedicated bearer method before
   relying on this — if one exists, prefer it and drop the interceptor.
2. **`UserModel.UserRemovedEvent` / `GroupModel.GroupRemovedEvent`** are internal Keycloak model
   events, not public SPI contracts — their shape has been stable across recent major versions but
   isn't guaranteed the way `EventListenerProviderFactory` is. Confirm against the Keycloak version
   you're actually running (check `org.keycloak.models.UserModel` / `GroupModel` source for that
   version) before deploying to something you care about.
3. **Retry policy** in `ScimSyncService` is a simple fixed-backoff retry (3 attempts). If your SCIM
   server has a JWKS mismatch or auth hiccup like the one you're working around for the Keycloak/
   Azure AD dual-IDP setup, failed calls will retry 3x and then just log an error — there's no
   dead-letter/outbox table here. If you need guaranteed delivery across Keycloak restarts, that's
   the next thing to add (a small outbox table + scheduled retry job, similar in spirit to the
   delta-sync pattern from your Security Server Migration Module).
4. **Admin console UI tab** — see the "Admin console UI" section above; this is the least-verified
   part of the whole extension since it relies on an experimental Keycloak SPI I could only check
   against one reference example.
5. **Group membership PATCH `remove` filter syntax** (`members[value eq "..."]`) follows RFC7644,
   but confirm your SCIM server's PATCH filter-path handling accepts it exactly this way — you
   already know from your `UserResourceHandler` work that PATCH filter-path parsing has server-side
   nuances.
