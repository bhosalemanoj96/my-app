package com.example.keycloak.scim;

import org.keycloak.Config;

/**
 * Configuration for the SCIM provisioning event listener.
 *
 * Values are read from the provider config in standalone.xml / keycloak.conf, e.g.:
 *
 *   spi-events-listener-scim-provisioning-scim-base-url=https://scim.example.com/scim/v2
 *   spi-events-listener-scim-provisioning-auth-mode=BEARER
 *   spi-events-listener-scim-provisioning-bearer-token=${env.SCIM_BEARER_TOKEN}
 *
 * or via env vars as a fallback (useful for quick container-based setups). Provider config
 * always wins over env vars if both are set.
 */
public class ScimProvisioningConfig {

    public enum AuthMode { NONE, BASIC, BEARER }

    private final String baseUrl;
    private final AuthMode authMode;
    private final String basicUsername;
    private final String basicPassword;
    private final String bearerToken;
    private final String externalIdAttribute;
    private final int asyncThreads;
    private final int connectTimeoutSeconds;
    private final int requestTimeoutSeconds;
    private final boolean skipTlsVerify;

    private ScimProvisioningConfig(Builder b) {
        this.baseUrl = b.baseUrl;
        this.authMode = b.authMode;
        this.basicUsername = b.basicUsername;
        this.basicPassword = b.basicPassword;
        this.bearerToken = b.bearerToken;
        this.externalIdAttribute = b.externalIdAttribute;
        this.asyncThreads = b.asyncThreads;
        this.connectTimeoutSeconds = b.connectTimeoutSeconds;
        this.requestTimeoutSeconds = b.requestTimeoutSeconds;
        this.skipTlsVerify = b.skipTlsVerify;
    }

    public static ScimProvisioningConfig from(Config.Scope scope) {
        Builder b = new Builder();
        b.baseUrl = firstNonNull(scope.get("scim-base-url"), System.getenv("SCIM_BASE_URL"));
        b.authMode = AuthMode.valueOf(
                firstNonNull(scope.get("auth-mode"), System.getenv("SCIM_AUTH_MODE"), "NONE").toUpperCase());
        b.basicUsername = firstNonNull(scope.get("basic-username"), System.getenv("SCIM_BASIC_USERNAME"));
        b.basicPassword = firstNonNull(scope.get("basic-password"), System.getenv("SCIM_BASIC_PASSWORD"));
        b.bearerToken = firstNonNull(scope.get("bearer-token"), System.getenv("SCIM_BEARER_TOKEN"));
        b.externalIdAttribute = firstNonNull(scope.get("external-id-attribute"),
                System.getenv("SCIM_EXTERNAL_ID_ATTRIBUTE"), "scimExternalId");
        b.asyncThreads = Integer.parseInt(
                firstNonNull(scope.get("async-threads"), System.getenv("SCIM_ASYNC_THREADS"), "2"));
        b.connectTimeoutSeconds = Integer.parseInt(
                firstNonNull(scope.get("connect-timeout-seconds"), System.getenv("SCIM_CONNECT_TIMEOUT"), "5"));
        b.requestTimeoutSeconds = Integer.parseInt(
                firstNonNull(scope.get("request-timeout-seconds"), System.getenv("SCIM_REQUEST_TIMEOUT"), "10"));
        b.skipTlsVerify = Boolean.parseBoolean(
                firstNonNull(scope.get("skip-tls-verify"), System.getenv("SCIM_SKIP_TLS_VERIFY"), "false"));

        if (b.baseUrl == null || b.baseUrl.isBlank()) {
            throw new IllegalStateException(
                    "SCIM provisioning extension is misconfigured: scim-base-url (or SCIM_BASE_URL) is required");
        }
        return new ScimProvisioningConfig(b);
    }

    private static String firstNonNull(String... values) {
        for (String v : values) {
            if (v != null && !v.isBlank()) return v;
        }
        return null;
    }

    public String getBaseUrl() { return baseUrl; }
    public AuthMode getAuthMode() { return authMode; }
    public String getBasicUsername() { return basicUsername; }
    public String getBasicPassword() { return basicPassword; }
    public String getBearerToken() { return bearerToken; }
    public String getExternalIdAttribute() { return externalIdAttribute; }
    public int getAsyncThreads() { return asyncThreads; }
    public int getConnectTimeoutSeconds() { return connectTimeoutSeconds; }
    public int getRequestTimeoutSeconds() { return requestTimeoutSeconds; }
    public boolean isSkipTlsVerify() { return skipTlsVerify; }

    private static class Builder {
        String baseUrl;
        AuthMode authMode;
        String basicUsername;
        String basicPassword;
        String bearerToken;
        String externalIdAttribute;
        int asyncThreads;
        int connectTimeoutSeconds;
        int requestTimeoutSeconds;
        boolean skipTlsVerify;
    }
}
