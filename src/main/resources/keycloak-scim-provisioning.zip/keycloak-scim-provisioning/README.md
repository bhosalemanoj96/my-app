# keycloak-scim-provisioning

A Keycloak **Event Listener SPI** extension that pushes user/group provisioning changes to your
SCIM server, using the Captain-P-Goldfish `scim-sdk-client` library — the same SDK family as your
`scim-sdk-server` implementation. This makes Keycloak a second SCIM-provisioning source alongside
Azure AD.

## Operations covered

| Keycloak action                                   | Trigger                          | SCIM call                          |
|----------------------------------------------------|-----------------------------------|-------------------------------------|
| Create user (admin console / Admin REST / self-register) | AdminEvent / Event               | `POST /Users`                      |
| Update user (profile, enable/disable, name, email)  | AdminEvent / Event (UPDATE_PROFILE) | `PUT /Users/{id}`                |
| Delete user                                         | `UserModel.UserRemovedEvent`      | `DELETE /Users/{id}`               |
| Create group                                        | AdminEvent                       | `POST /Groups`                     |
| Update group (rename)                               | AdminEvent                       | `PUT /Groups/{id}`                 |
| Delete group                                        | `GroupModel.GroupRemovedEvent`   | `DELETE /Groups/{id}`              |
| User joins group                                    | AdminEvent (GROUP_MEMBERSHIP, CREATE) | `PATCH /Groups/{id}` (add member) |
| User leaves group                                   | AdminEvent (GROUP_MEMBERSHIP, DELETE) | `PATCH /Groups/{id}` (remove member) |

Realm role / client role mappings are **not** mapped to SCIM groups in this phase — add that in
`ScimEventListenerProvider` if you need it (map `ResourceType.REALM_ROLE_MAPPING` similarly to
`GROUP_MEMBERSHIP`).

## Why DELETE is handled differently

Keycloak's `AdminEvent` for a DELETE operation fires *after* the entity is gone, with no
representation — there's nothing to read the SCIM external ID from. Instead this extension
registers `KeycloakSessionFactory` model-event listeners (`UserModel.UserRemovedEvent`,
`GroupModel.GroupRemovedEvent`) in `postInit()`. These fire synchronously, inside the same
transaction as the removal, while the entity is still readable, so the `scimExternalId` attribute
can be captured before it disappears. Only the actual outbound HTTP DELETE is dispatched
asynchronously — reading the attribute itself is synchronous and cheap.

## Correlation / external ID tracking

Each Keycloak user/group gets a single attribute (default name `scimExternalId`, configurable)
holding the SCIM server's assigned resource ID once first synced. Its presence is what
distinguishes "needs POST" from "needs PUT/PATCH".

## Build

Update `keycloak.version` and `scim.sdk.version` in `pom.xml` to match your actual server/SDK
versions (this was scaffolded assuming the SDK version your `scim-sdk-server` v1.32.0 pairs with —
double check against your existing pom).

```bash
mvn clean package
```

This produces `target/keycloak-scim-provisioning.jar`, shaded with the SCIM-SDK client and its
HTTP client dependencies (Keycloak's own SPI/core jars stay `provided` and are not shaded, to
avoid classpath conflicts with what the server already provides).

## Deploy

Copy the jar into Keycloak's providers directory and rebuild:

```bash
cp target/keycloak-scim-provisioning.jar $KEYCLOAK_HOME/providers/
$KEYCLOAK_HOME/bin/kc.sh build
```

## Configure

Via `keycloak.conf` / CLI (preferred):

```
spi-events-listener-scim-provisioning-scim-base-url=https://your-scim-server.example.com/scim/v2
spi-events-listener-scim-provisioning-auth-mode=BEARER
spi-events-listener-scim-provisioning-bearer-token=${env.SCIM_BEARER_TOKEN}
spi-events-listener-scim-provisioning-async-threads=2
```

Or via env vars as a fallback: `SCIM_BASE_URL`, `SCIM_AUTH_MODE` (`NONE`/`BASIC`/`BEARER`),
`SCIM_BASIC_USERNAME`/`SCIM_BASIC_PASSWORD`, `SCIM_BEARER_TOKEN`, `SCIM_EXTERNAL_ID_ATTRIBUTE`,
`SCIM_ASYNC_THREADS`, `SCIM_CONNECT_TIMEOUT`, `SCIM_REQUEST_TIMEOUT`, `SCIM_SKIP_TLS_VERIFY`.

Then enable the listener on the realm: Admin Console → Realm Settings → Events → Event Listeners
→ add `scim-provisioning`. **Also enable "Save events" for admin events with "include
representation" on**, or AdminEvent payloads may not carry what's needed.

## Things worth verifying before you trust this in anything beyond a dev/test integration

1. **Bearer auth wiring** (`ScimClientHolder`): the SCIM-SDK client wiki only documents
   `basicAuth(...)` and client-cert auth directly on `ScimClientConfig`; bearer token support here
   is implemented via a preconfigured Apache `HttpClientBuilder` interceptor, based on release
   notes mentioning that `ScimClientConfig` accepts preconfigured http-client-builders. Check your
   exact `scim-sdk-client` version's `ScimClientConfig` for a dedicated bearer method before
   relying on this — if one exists, prefer it and drop the interceptor.
2. **`UserModel.UserRemovedEvent` / `GroupModel.GroupRemovedEvent`** are internal Keycloak model
   events, not public SPI contracts — their shape has been stable across recent major versions but
   isn't guaranteed the way `EventListenerProviderFactory` is. Confirm against the Keycloak version
   you're actually running (check `org.keycloak.models.UserModel` / `GroupModel` source for that
   version) before deploying to something you care about.
3. **Retry policy** in `ScimSyncService` is a simple fixed-backoff retry (3 attempts). If your SCIM
   server has a JWKS mismatch or auth hiccup like the one you're working around for the Keycloak/
   Azure AD dual-IDP setup, failed calls will retry 3x and then just log an error — there's no
   dead-letter/outbox table here. If you need guaranteed delivery across Keycloak restarts, that's
   the next thing to add (a small outbox table + scheduled retry job, similar in spirit to the
   delta-sync pattern from your Security Server Migration Module).
4. **Group membership PATCH `remove` filter syntax** (`members[value eq "..."]`) follows RFC7644,
   but confirm your SCIM server's PATCH filter-path handling accepts it exactly this way — you
   already know from your `UserResourceHandler` work that PATCH filter-path parsing has server-side
   nuances.
